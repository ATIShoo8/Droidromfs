# DroidRomFS

Android-first starter project for a homebrew Nintendo Switch package (NSP) inspection/extraction workflow.

**Current status:** project scaffold only. The Android UI and native bridge are present, but the `nstool` ROMFS extraction backend is not yet integrated. This ZIP is not a working extractor yet.

## Requirements
- Android Studio or Android command-line build tools
- Android SDK / NDK
- CMake
- A legally obtained NSP file and the keys/permissions required by the format and your own device

## Project layout
- `app/src/main/java/com/droidromfs/app/MainActivity.kt` — Android entry point and document picker
- `app/src/main/cpp/native-lib.cpp` — JNI bridge placeholder for the native extraction engine
- `app/src/main/cpp/CMakeLists.txt` — native build configuration
- `app/src/main/res/` — app label and theme resources

## Android-only development
You can edit this project using an Android code editor or a cloud Git workflow, but compiling the native Android app requires an Android SDK/NDK toolchain. The project is configured for Android Gradle Plugin and CMake.

## Next implementation step
Integrate a compatible `nstool` source/build into `app/src/main/cpp/`, then implement the ROMFS extraction call behind `nativeExtractRomfs()`. Keep all file access inside Android's Storage Access Framework rather than assuming direct filesystem paths.

## Build
Open this folder in Android Studio, allow Gradle sync, then build the `app` module. The initial scaffold will build only after the Android SDK/NDK versions in your environment are installed.
