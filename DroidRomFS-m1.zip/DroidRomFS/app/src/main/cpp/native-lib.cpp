#include <jni.h>
#include <string>

// Milestone 1: engine status only. No extraction is implemented yet.
extern "C" JNIEXPORT jstring JNICALL
Java_com_droidromfs_app_NstoolBridge_nativeEngineStatus(JNIEnv* env, jobject) {
    const std::string message =
        "DroidRomFS 0.1.0\n"
        "Engine: NSTool (not yet integrated)\n"
        "Extraction: unavailable";
    return env->NewStringUTF(message.c_str());
}
