package com.droidromfs.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import android.content.Intent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF7C9CFF))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF0E1116)) { Home() }
            }
        }
    }

    @Composable
    private fun Home() {
        var name by remember { mutableStateOf<String?>(null) }
        var size by remember { mutableStateOf<Long?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: SecurityException) { /* provider doesn't offer persistable grants */ }
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                        size = c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE))
                    }
                }
            }
        }
        Column(Modifier.padding(24.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("DroidRomFS", style = MaterialTheme.typography.headlineMedium)
            Text(NstoolBridge.nativeEngineStatus(), style = MaterialTheme.typography.bodyMedium)
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Select NSP") }
            name?.let { Text("File: $it") }
            size?.let { Text("Size: $it bytes") }
        }
    }
}
