package com.droidromfs.app

/** JNI entry point. Only the engine status call exists so far. */
object NstoolBridge {
    init { System.loadLibrary("droidromfs") }
    external fun nativeEngineStatus(): String
}
